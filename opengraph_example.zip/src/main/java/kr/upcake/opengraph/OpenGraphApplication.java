package kr.upcake.opengraph;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenGraphApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenGraphApplication.class, args);
	}

}
